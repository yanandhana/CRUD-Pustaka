<?php
//file config.php
define('BASEPATH', 'http://localhost/literasi/');
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBPASS', '');
define('DBNAME', 'simpustaka');