<nav> 
    <a href="<?= BASEPATH ?>public/index.php">Home</a>
    <a href="<?= BASEPATH ?>src/pengarang">Pengarang</a>
    <a href="<?= BASEPATH ?>src/buku">Buku</a>
</nav>