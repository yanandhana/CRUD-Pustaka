<footer>
    <small><i>Copyright &copy; 2021</i></small>
</footer>
</body>
</html>