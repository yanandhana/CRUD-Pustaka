<?php
include '../../config/config.php';
include '../fragment/header.php';
include '../fragment/menu.php';
include '../fragment/function.php';
?>
    <header>
        <h1>Hapus Data</h1>
    </header>
    <main>
        <?php
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $query = "DELETE FROM pengarang WHERE id='$id'";
            $con = connect_db();
            execute_query($con, $query);
            if(mysqli_affected_rows($con) != 0){
                echo "Data berhasiil dihapus";
            }else{
                echo "data tidak berhasil dihapus";
            }
        }
        ?>
    </main>
    <?php include '../fragment/footer.php'; ?>